# Vorlage für das HPI-Sommercamp 2021

## Installation der notwendigen Erweiterungen für VS Code
- Unten rechts in Eurem VS Code-Fenster solltet Ihr zur Installation der notwendigen Erweiterungen aufgefordert werden. 
  - klickt hier auf "Install"

## Webseite schreiben
- Die Quelldateien für Euer Projekt befinden sich im Unterordner 'src/' 
- Ihr könnt mit der Datei index.html loslegen

## Webseiten anzeigen
- Voraussetzung zur gemeinsamen Verwendung ist, dass Ihr Euren Arbeitsbereich per Live Share teilt. 
- Startet zum Ausprobieren den Live Server mit dem Button unten rechts in der Ecke

- Sowohl Ihr als auch Eure Teammitglieder können dann unter http://localhost:5500/src/ Eure Webseite sehen.
