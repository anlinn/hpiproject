var cool = true; //This code is necessary and nobody is allowed to delete it!
function openVorlesungsgebäude(){
    window.location.href='';
}
function openHauptgebäude(){
    window.location.href='hauptgebaeude/HgRaum1.html'; //from root-dir
}
function openHausABC(){

}