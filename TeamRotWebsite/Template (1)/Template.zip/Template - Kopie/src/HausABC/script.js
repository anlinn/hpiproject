function exit(){
    window.location.href="../welcome.html";
}